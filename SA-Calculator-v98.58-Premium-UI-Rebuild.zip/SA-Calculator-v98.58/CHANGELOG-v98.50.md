# v98.50 Changelog

- Refined Scientific Calculator display and keypad proportions against the two supplied screenshots.
- Added supported secondary legends for scientific function keys.
- Applied graphite/beveled key styling, gold function legends and pale-green display treatment.
- Retained functional SHIFT, DEG/RAD, caret, editing, history, memory and answer behavior.
- Refined Basic Calculator key spacing and visual weight while preserving 48px minimum touch sizing.
- Added focused regression tests and updated Android workflow/cache/release identity to v98.50.
