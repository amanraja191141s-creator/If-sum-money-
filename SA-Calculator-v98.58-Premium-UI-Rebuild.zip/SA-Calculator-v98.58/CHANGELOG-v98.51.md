# v98.51 Changelog

- Added complete master UI/system blueprint grounded in the v98.50 source package and supplied references.
- Documented exact placement, sizing, behavior and keyboard contracts for all 17 tool screens, Basic/Scientific, Settings, History, Favorites, navigation, pickers and dialogs.
- Added responsive master CSS layer for tool toolbar, five-destination navigation, tools grid, shared form rhythm, Settings rows, History surface and keypad sheet.
- Added machine-readable screen/tool inventory.
- Updated web bundle, service worker cache, package identity and exact-source Android workflow to v98.51 / 1098051.
- Preserved existing calculation engines and avoided advertising unsupported advanced math engines.
