# Changelog v98.52

- Replaced the old Home visual presentation with the approved SA Calculator dark navy/blue reference direction.
- Added a framed expression/result display and balanced five-row, four-column keypad.
- Made zero span two columns and standardized full-cell key sizing.
- Changed the Home bottom-navigation label from Calculator to Home.
- Replaced the top-right tool-search shortcut with a direct History action; Tools retains its own search field.
- Preserved existing calculation DOM, handlers, tools, and saved data.
- Added light-theme, compact-height, narrow-width, and landscape styling.
- Bumped app identity to 1.98.52-v98.52 / Android versionCode 1098052.
