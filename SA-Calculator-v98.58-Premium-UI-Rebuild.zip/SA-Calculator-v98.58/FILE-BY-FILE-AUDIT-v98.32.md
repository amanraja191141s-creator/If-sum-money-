# File-by-file audit — v98.32

| File | v98.32 treatment |
|---|---|
| `index.html` | Removed obsolete currency picker modal; loads authoritative v98.32 stylesheet; Fuel Efficiency result gets explicit state ID |
| `assets/css/app.css` | Removed obsolete dedicated currency-picker rules and legacy pseudo-header/pseudo-title rules; retained foundational compatibility/layout styles used by existing tools |
| `assets/css/rebuild-v98.32.css` | New authoritative UI layer for header, real tool toolbar, drawer, unified picker, Body Metrics, Fuel Cost, Fuel Efficiency, Loan, Unit Price, World Time, custom keypad and Scientific panel |
| `assets/js/app.js` | Removed duplicate currency picker runtime/handlers; added flags and metadata to unified picker; corrected Body Metrics empty status and Fuel Efficiency result states |
| `service-worker.js` | New cache namespace and precache entry for v98.32 stylesheet |
| `scripts/prepare-android-web.mjs` | Requires/copies v98.32 stylesheet into Android web bundle |
| `.github/workflows/main.yml` | Exact v98.32 source selection, version identity, required CSS asset and APK checks |
| `tests/` | Updated legacy UI expectations and added authoritative rebuild regressions |
| `www/` | Generated Android web bundle from the same source stylesheet and scripts |

## Deliberately preserved

Existing calculator engines and state/data handling were not destructively replaced. Legacy compatibility CSS remains only where existing screen structures and calculation controls depend on it; obsolete competing currency-picker and pseudo-toolbar systems were removed. The v98.32 stylesheet is loaded last and is the active visual authority.
