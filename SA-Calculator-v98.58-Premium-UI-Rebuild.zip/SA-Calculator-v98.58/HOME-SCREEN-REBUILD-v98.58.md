# SA Calculator v98.58 — Premium UI Rebuild

## Design direction
The supplied reference images define a premium graphite/charcoal interface with soft neutral calculator keys, a vivid indigo operator rail, a restrained teal accent for history values, compact scientific controls, paired converter cards, and a visible theme palette.

## Implemented
- Main calculator: open expression/result display; 4-column, 5-row keypad; neutral utility keys; indigo operators; responsive key sizing.
- Scientific calculator: independent dark workspace, readable expression/result hierarchy, function matrix, angle/shift states retained.
- Tools: search, category chips, compact cards and persistent scroll behavior retained.
- History: teal result emphasis, graphite row cards and existing clear/delete/copy actions retained.
- Currency and unit converters: paired input surfaces, distinct selectors, swap action and refresh/status treatment retained.
- Settings and themes: consistent rows, switches, dialogs and 4-column theme swatch presentation.
- Finance and utility tools: shared typography, form controls, result surfaces and focus treatment.
- Light theme: explicit light-surface overrides; dark remains the reference default.

## Engineering constraints
This release is a CSS-first visual redesign. Existing JavaScript calculation engines, event delegation, data persistence, currency providers, localization and tool routes are preserved. Reduced-motion, focus-visible and safe-area behavior remain supported.

## Validation boundary
Automated tests and Android web-bundle generation are run separately. A successful web bundle is not proof of a successful APK install or physical-device visual validation; those require the GitHub Actions Android build and device testing.
