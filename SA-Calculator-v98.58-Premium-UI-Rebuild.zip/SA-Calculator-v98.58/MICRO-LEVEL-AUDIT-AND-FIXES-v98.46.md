# Micro-level UI audit and fixes — v98.46

## Baseline observations from v98.45 source
1. The design was spread across 11 ordered CSS layers, making the final cascade hard to reason about.
2. Shared color values differed between the base theme, light-theme overrides and later tool-menu patches.
3. Card and input corner radii varied across tool screens.
4. Tool cards, category chips and search control had slightly inconsistent sizing and spacing at narrow widths.
5. The final design layer was not yet a single explicit source of truth for the app-wide palette and shape scale.

## Implemented in v98.46
1. Added a final unified palette for dark and light themes, including app, surface, field, text, muted, border and accent tokens.
2. Added a shared radius scale (10/13/17/21/26px) and common control height token.
3. Standardized common tool cards, result/settings cards and form controls to the shared radius scale.
4. Refined app header, bottom navigation, active navigation state and focus-visible ring.
5. Kept calculator expression/result display borderless as previously requested.
6. Refined Tools title, search field, category chips, card dimensions, icon dimensions, spacing, borders, shadows and pressed state.
7. Added compact 360px rules and wider tablet sizing without changing the two-column grid.
8. Preserved reduced-motion support and keyboard accessibility.
9. Added the v98.46 layer to builder and CI required-asset checks; regenerated Android web bundle.
10. Updated release identity and service-worker cache.

## Preserved systems
- Existing screen IDs and all 17 Tools cards.
- Existing calculation handlers and scientific modal engine.
- Currency and unit converter behavior, custom keypad actions and accessibility labels.
- Theme switching, history, favorites and settings.

## Validation boundary
Automated source regression, JavaScript syntax, web-bundle, YAML parse and ZIP integrity checks are run for this release. A physical Android screenshot/interaction/performance run is still required before claiming pixel-perfect device rendering or zero lag.
