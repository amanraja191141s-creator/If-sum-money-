# SA Calculator v98.47 — Micro-level audit and fixes

## Baseline weaknesses found in v98.46

1. Scientific Calculator was a modal (`#sci-modal-overlay`), not an independent screen.
2. The drawer exposed a Scientific shortcut that opened that modal over the basic calculator.
3. The basic calculator exposed `ƒx`, `xʸ` and DEG/RAD controls in its own sub-toolbar.
4. Scientific function buttons called `insertScientificFunction`, which read and mutated `STATE.calcExpr`, cursor/selection, `STATE.calcVal`, result mode and scientific continuation metadata belonging to the basic calculator.
5. The scientific trig evaluator read global `STATE.isDegMode`; angle selection was not owned by a separate calculator instance.
6. Scientific memory used the basic calculator's `STATE.memoryValue`, `STATE.memoryHasValue` and `sumaire_memory_v1` storage key.
7. Scientific calculations had no separate expression/result history, independent ANS or isolated persistent memory/history.
8. Old modal HTML, modal focus lifecycle, and obsolete insertion helper functions were left in the source after earlier UI revisions.

## Exact v98.47 changes

### Basic Calculator

- Removed `#btn-sci-inline`, `data-calc="^"`, the DEG/RAD toggle and the old scientific toolbar.
- Removed the drawer's Scientific Calculator shortcut.
- Removed basic-screen memory controls and the old shared memory state/functions.
- Basic keypad now contains only AC, sign, percent, arithmetic operators, digits, decimal and equals.

### Scientific Calculator

- Added `#screen-scientific` as a standalone `.screen`, navigated directly from the Scientific Calculator card in Tools.
- Added an independent expression input (`#sci-expression`) and result output (`#sci-result`).
- Added a dedicated scientific function grid and keypad, separate from all `data-calc` basic keypad actions.
- Added local DEG/RAD controls, persisted under `sa_scientific_angle_v1`.
- Added isolated MC, MR, M+, M− and MS memory, persisted under `sa_scientific_memory_v1`.
- Added independent history (last 50 calculations), tap-to-restore and clear, persisted under `sa_scientific_history_v1`.
- Added ANS recall based on the independent scientific answer/history.
- Added π, e, xʸ, √, ∛, abs, factorial, reciprocal, log, ln, log₂, sin/cos/tan, inverse trig, hyperbolic functions, eˣ, 10ˣ, x² and x³.

### Engine separation

- `evaluateArithmetic(expression, allowImplicitMultiplication, angleMode)` now accepts an explicit angle mode.
- Scientific Calculator always passes its own `sci.angle`.
- Removed global `STATE.isDegMode`, `applySettingAngle`, and settings angle wiring.
- Removed `scientificOperandRange`, `buildScientificResultExpression` and `insertScientificFunction`, which were part of the old bridge into basic calculator state.
- The arithmetic parser remains shared as a pure calculation engine; the two calculator interfaces and mutable states are separate.

### Android / release

- Added `assets/css/rebuild-v98.47.css`.
- Android web bundle builder requires and compiles the new CSS layer.
- Service Worker cache bumped to `sa-calculator-v98-47-isolated-scientific-screen`.
- Source HTML, manifest, package, runtime, workflow and downloadable YAML use `1.98.47-v98.47` and Android versionCode `1098047`.

## Remaining limitations

- This workspace did not run a hosted GitHub Actions Android build or install the resulting APK on a physical phone.
- Touch latency, FPS, memory and battery were not measured on-device.
- The calculator engine is JavaScript Number-based (IEEE-754 double precision); this release does not add arbitrary-precision decimal or symbolic algebra.

## Scientific-calculator benchmark notes

Current product descriptions and official help pages were checked for GeoGebra Scientific Calculator, HiPER, Desmos Scientific Calculator, CalcTastic, and recent Android scientific-calculator listings. Repeated baseline patterns include a distinct scientific workspace or mode, DEG/RAD selection, trigonometric and inverse-trigonometric functions, logarithms, powers/roots, constants, factorial, memory and calculation history. More advanced products additionally advertise fractions, statistics, complex numbers, graphing, matrices, symbolic algebra, GRAD mode, physical constants and RPN.

SA Calculator v98.47 implements the isolated scientific workspace and the baseline function/memory/history set described above. It does **not** claim to implement the advanced categories (fractions, statistics, complex arithmetic, graphing, matrices, symbolic algebra, GRAD or RPN); no placeholder buttons for those unsupported features were added.
