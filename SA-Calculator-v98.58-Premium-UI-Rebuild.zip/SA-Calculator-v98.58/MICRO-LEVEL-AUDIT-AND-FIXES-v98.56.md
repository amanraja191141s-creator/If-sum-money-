# v98.56 — Screen recording micro-audit

## Source-derived findings
1. The currency picker constructed the flag with `currencyFlagForCode(item.code)`, but `item` is a button element and no `code` property was assigned. The ISO code is already available in the local `code` variable; the picker now uses it.
2. The application shell is fixed to the viewport. The screen recording shows the Android keyboard covering the lower tool-search content. A `visualViewport` resize/scroll listener now publishes the visible height as a CSS custom property, and the app container follows it.
3. Tool search/category controls and tool cards now have explicit flex sizing; only the cards list scrolls vertically.
4. Scientific Calculator had a legacy green LCD / gray key palette that visibly differed from the app's dark-blue interface. v98.56 applies coordinated dark and light theme styles without altering its event handlers or key layout.

## Automated verification
- Added five focused regression tests for the fixes and release identity.
- Full project tests and web bundle build are run before delivery.
- These source-level tests do not replace physical Android validation, accessibility checks with assistive technology, or APK installation/performance testing.
