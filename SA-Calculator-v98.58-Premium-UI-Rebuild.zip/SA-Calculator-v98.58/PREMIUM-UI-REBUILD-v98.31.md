# SA Calculator v98.32 — Premium UI Rebuild

## Rebuild scope
- Replaced the navigation drawer presentation with a searchable, categorized 16-tool library.
- Added a dynamic Quick access section sourced from saved favorites.
- Restored a visible hamburger entry point on the calculator home header; tool screens retain their own single toolbar.
- Added representative country/territory flags for every currency in the 105-code selectable catalog, with ISO currency code and localized name kept as the authoritative labels.
- Currency picker rows now show flag, full currency name, ISO code, selected state, search and alphabetical jump index.
- Scientific functions are grouped into constants, powers/roots, logarithms, trigonometry and hyperbolic sections.
- On-demand numeric keypad is restyled as a safe-area-aware bottom sheet with focused-field preview, 4×4 controls, delete, next, clear and done.
- All tool cards, fields, result surfaces, actions and tool headers use a shared premium navy/blue/green design system.
- Bottom navigation active state and touch dimensions standardized.

## Functionality preservation
The existing calculation engines, currency providers, currency cache/freshness logic, calculator parser, memory operations, tool screen IDs, settings, favorites, history, date/time and unit conversion logic were preserved. The UI rebuild does not replace these engines.

## Currency flag note
Flags are representative territory identifiers, not definitive proof of legal tender coverage. EUR uses the EU flag; XAF/XOF/XPF use representative regional/territory flags. ISO 4217 code and localized currency name remain the source of truth.

## Verification boundary
Source syntax, project tests and web bundle can be checked in this environment. Physical Android installation, device screenshots, live network/provider behavior, FPS, memory, battery and APK signing are not certified until the generated APK is installed and tested on a real device.
