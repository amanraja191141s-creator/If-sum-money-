# QA Results — SA Calculator v98.54

## Verified in this build environment

- Automated regression suite: **340 passed, 0 failed** (`npm test`).
- JavaScript syntax: **PASS** for app runtime, localization, currency names, theme bootstrap, server, service worker and Android build scripts.
- Android web bundle: **PASS**; 28 required source assets verified and 18 CSS source layers consolidated into `www/assets/css/app.css`.
- CSS parsing: **PASS** for the authoritative Home layer and consolidated production stylesheet (tinycss2 parser; no parse errors).
- YAML parsing: **PASS** for `.github/workflows/main.yml` and the downloadable root YAML.
- Workflow parity: **PASS**; both workflow files are byte-identical.
- Source-chain audit: **PASS**; v98.52 Home CSS is no longer in the active source chain.
- Root-cause regression: **PASS**; v98.50 global `display:none!important` Home-header rule is removed.
- Header behavior: **PASS by source regression**; header is visible on Home and Tools and hidden on child tool/settings/favorites screens using the existing `tool-screen-active` state.
- Bottom navigation hidden-state specificity: **PASS by source regression**; `[hidden]` now outranks the ID-scoped visible navigation rule.
- ZIP integrity: verified after packaging.

## Explicitly not verified here

- A headless Chromium screenshot attempt timed out in this runner, so no browser-rendered visual screenshot is claimed.
- No physical Android phone or OEM WebView was available for installation, touch, density, safe-area, rotation or performance profiling.
- The GitHub Actions workflow has not been executed here; no APK is included or claimed as built.

The automated checks establish source consistency and regression coverage, not a guarantee of zero defects or lag-free behavior on every Android device.
