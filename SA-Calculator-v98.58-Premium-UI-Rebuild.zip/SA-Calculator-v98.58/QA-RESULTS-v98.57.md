# QA Results — SA Calculator v98.57

Date: 2026-11-18

## UI scope delivered
- New shared visual layer `assets/css/rebuild-v98.57.css` added last in the production cascade.
- Covers 21 existing DOM screens plus the full-screen History overlay and searchable currency/unit picker: calculator, scientific, tools, favorites, settings and all 16 individual tool surfaces (including converters, finance, math and daily tools).
- Includes dark and light appearance overrides, consistent cards/fields/buttons, distinct scientific keypad, converter selectors, dock keypad, navigation, modal and focus-visible states.
- Honors reduced-motion preference.
- Preserves existing screen DOM, IDs, event handlers and calculator/converter engines.

## Automated verification
- `npm test`: 349 passed, 0 failed.
- `npm run build:web`: passed; 32 required assets verified and 20 CSS layers consolidated.
- JavaScript syntax checks: passed for app and build scripts.
- CSS parser: passed, 0 syntax errors in final consolidated stylesheet.
- YAML parser: passed for both workflow copies.
- Release identity: package, HTML, manifest, runtime, service-worker cache and workflow synchronized to `1.98.57-v98.57`.
- ZIP integrity: checked after packaging.

## Research basis
The 22-app UX benchmark in `RESEARCH-20-PLUS-ANDROID-CALCULATOR-APPS-v98.41.md` was used together with the supplied 71.7-second Android screen recording. Additional current product/reference checks were used to validate broad interaction patterns. No competitor artwork or proprietary assets were copied.

## Not claimed
- APK was not built or installed in this environment.
- No physical-device screenshots, TalkBack audit, touch-latency/frame-time measurements, memory profiling or battery tests were performed.
- Chromium headless preview was unavailable in this runtime, so visual QA remains pending on an Android device/emulator.
- Existing feature engines were preserved, not rewritten or independently certified by this UI-only release.
