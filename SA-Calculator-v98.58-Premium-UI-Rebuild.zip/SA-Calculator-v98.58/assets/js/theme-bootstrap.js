/* Premium reference skin bootstrap: ignore stale legacy palette preferences. */
(function bootstrapPremiumReferenceTheme() {
  document.documentElement.style.setProperty('--sa-initial-accent', '#4d5cff');
  document.documentElement.style.colorScheme = 'dark';
  document.documentElement.setAttribute('data-theme', 'dark');
  document.documentElement.setAttribute('data-theme-mode', 'dark');
})();
