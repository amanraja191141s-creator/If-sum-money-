import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = p => fs.readFileSync(path.join(root, p), 'utf8');

test('premium design system defines consistent tool surfaces, controls and result hierarchy', () => {
  const css = read('assets/css/app.css');
  assert.match(css, /SA CALCULATOR v98\.27 — PREMIUM FINISH PASS/);
  assert.match(css, /--sa-premium-control:\s*52px/);
  assert.match(css, /border-radius:\s*var\(--sa-premium-radius\)/);
  assert.match(css, /\.result-card\s*\{[\s\S]*?background:\s*linear-gradient\(145deg, rgba\(7,93,75/);
  assert.match(css, /prefers-reduced-motion:\s*reduce/);
});

test('currency converter has premium source, target, swap, result, rate and picker states', () => {
  const html = read('index.html'); const css = read('assets/css/app.css'); const js = read('assets/js/app.js');
  for (const id of ['cur-from','cur-to','cur-amount','cur-to-amount','btn-cur-swap','cur-rate-status','cur-refresh-time','currency-convert-action','btn-refresh-rates']) assert.ok(html.includes(`id="${id}"`), `missing ${id}`);
  assert.match(css, /#screen-currencies \.currency-parity-card\s*\{[\s\S]*?border-radius:\s*17px/);
  assert.match(css, /#screen-currencies \.currency-result-input\s*\{[\s\S]*?background:\s*linear-gradient\(145deg, #075d4d/);
  assert.match(read('assets/css/rebuild-v98.32.css'), /\.sumaire-picker-option-flag/);
  assert.match(js, /currencyFlagForCode\(code\)/);
  assert.match(js, /sumaire-picker-option-flag/);
  assert.match(js, /refreshCurrencyRates\(false\)/);
});

test('premium pass preserves calculator-only permanent keypad and on-demand tool keypad contract', () => {
  const js = read('assets/js/app.js'); const html = read('index.html');
  assert.match(js, /PERMANENT_DOCKED_SCREENS/);
  assert.match(html, /id="screen-calc"[\s\S]*?class="main-keypad"/);
  assert.match(html, /id="screen-currencies"[\s\S]*?class="dock-keypad currency-dock-keypad"/);
  assert.match(html, /id="screen-units"[\s\S]*?class="dock-keypad"/);
});

test('source and generated web bundle use the same premium stylesheet after build', () => {
  assert.equal(read('assets/css/app.css'), read('www/assets/css/app.css'));
});
