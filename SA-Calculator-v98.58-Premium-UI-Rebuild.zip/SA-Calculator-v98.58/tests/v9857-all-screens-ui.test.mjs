import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
const root = path.resolve('.');
test('v98.58 all-screen visual layer is included in Android bundle', () => {
  const build = fs.readFileSync('scripts/prepare-android-web.mjs','utf8');
  assert.match(build,/rebuild-v98\.58\.css/);
  assert.ok(fs.existsSync('assets/css/rebuild-v98.58.css'));
});
test('v98.58 design layer covers all primary and tool surfaces', () => {
  const css = fs.readFileSync('assets/css/rebuild-v98.58.css','utf8');
  for (const selector of ['#screen-calc','#screen-scientific','#screen-tools','#screen-favorites','#screen-settings','#screen-currencies','#screen-units','#screen-discount','#screen-percent','#screen-salestax','#screen-bodymetrics','#screen-date','#screen-fuelcost','#screen-fuelefficiency','#screen-gradeavg','#screen-hex','#screen-loan','#screen-savings','#screen-tip','#screen-unitprice','#screen-worldtime']) {
    assert.ok(css.includes(selector),`Missing UI coverage for ${selector}`);
  }
  assert.match(css,/prefers-reduced-motion/);
  assert.match(css,/focus-visible/);
  assert.match(css,/#history-modal/);
  assert.match(css,/currency-picker-dialog/);
  assert.match(css,/data-theme="light"/);
  const html=fs.readFileSync('index.html','utf8');
  for (const id of ['screen-calc','screen-scientific','screen-tools','screen-favorites','screen-settings','screen-currencies','screen-units','screen-discount','screen-percent','screen-salestax','screen-bodymetrics','screen-date','screen-fuelcost','screen-fuelefficiency','screen-gradeavg','screen-hex','screen-loan','screen-savings','screen-tip','screen-unitprice','screen-worldtime']) assert.ok(html.includes(`id="${id}"`),`Missing DOM screen ${id}`);
});
test('v98.58 release identity is synchronized', () => {
  const pkg=JSON.parse(fs.readFileSync('package.json','utf8'));
  assert.equal(pkg.version,'1.98.58-v98.58');
  const wf=fs.readFileSync('SA-Calculator-v98.58-Android-Workflow.yml','utf8');
  assert.match(wf,/1\.98\.58-v98\.58/);
  assert.match(wf,/SA-Calculator-v98\.58-Premium-UI-Rebuild\.zip/);
});
