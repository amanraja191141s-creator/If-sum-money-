import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
test('v98.58 premium graphite layer is included in deterministic Android CSS build',()=>{
 const builder=fs.readFileSync('scripts/prepare-android-web.mjs','utf8');
 assert.match(builder,/rebuild-v98\.58\.css/);
 assert.ok(fs.existsSync('assets/css/rebuild-v98.58.css'));
});
test('v98.58 supplied-reference styling covers every app destination without replacing handlers',()=>{
 const css=fs.readFileSync('assets/css/rebuild-v98.58.css','utf8');
 for(const id of ['calc','scientific','tools','favorites','settings','currencies','units','discount','percent','salestax','bodymetrics','date','fuelcost','fuelefficiency','gradeavg','hex','loan','savings','tip','unitprice','worldtime']) assert.ok(css.includes(`#screen-${id}`),`Missing ${id}`);
 for(const token of ['#history-modal','.theme-picker-options','.currency-parity-card','.main-keypad','prefers-reduced-motion','focus-visible','data-theme="light"']) assert.ok(css.includes(token),`Missing style contract ${token}`);
 const html=fs.readFileSync('index.html','utf8');
 assert.match(html,/data-calc="="/);
 assert.match(html,/data-bottom-nav="history"/);
 assert.match(html,/data-action="openThemePicker"/);
});
test('v98.58 release package, workflow and cache namespace are synchronized',()=>{
 const pkg=JSON.parse(fs.readFileSync('package.json','utf8'));
 assert.equal(pkg.version,'1.98.58-v98.58');
 const workflow=fs.readFileSync('SA-Calculator-v98.58-Android-Workflow.yml','utf8');
 assert.match(workflow,/1\.98\.58-v98\.58/);
 assert.match(workflow,/SA-Calculator-v98\.58-Premium-UI-Rebuild\.zip/);
 assert.match(fs.readFileSync('service-worker.js','utf8'),/sa-calculator-v98-58-premium-ui-rebuild-v9858/);
});
