import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const css = fs.readFileSync(path.join(root, "assets/css/app.css"), "utf8") + fs.readFileSync(path.join(root, "assets/css/rebuild-v98.32.css"), "utf8");
const bundledCss = fs.readFileSync(path.join(root, "www/assets/css/app.css"), "utf8") + fs.readFileSync(path.join(root, "www/assets/css/rebuild-v98.32.css"), "utf8");

test("video review: obsolete pseudo headers are disabled in favor of one real toolbar", () => {
  assert.match(css, /#screen-viewport\s*>\s*\.screen:not\(#screen-calc\)::before,[\s\S]*?display:\s*none\s*!important/);
  assert.match(css, /#screen-viewport\s*>\s*\.screen:not\(#screen-calc\)::after[\s\S]*?content:\s*none\s*!important/);
});

test("video review: settings cards and rows cannot collapse or clip their controls", () => {
  assert.match(css, /#screen-settings \.settings-card\s*\{[^}]*display:\s*flex\s*!important/);
  assert.match(css, /#screen-settings \.settings-card\s*\{[^}]*overflow:\s*visible\s*!important/);
  assert.match(css, /#screen-settings \.settings-row\s*\{[^}]*min-height:\s*52px\s*!important/);
  assert.match(css, /#screen-settings \.settings-label-group\s*\{[^}]*flex:\s*1 1 auto\s*!important/);
});

test("video review: all amortization columns remain reachable by horizontal scrolling", () => {
  assert.match(css, /#screen-viewport #screen-loan \.loan-table-wrap\s*\{[^}]*overflow-x:\s*auto\s*!important/);
  assert.match(css, /#screen-viewport #screen-loan \.amort-table\s*\{[^}]*min-width:\s*540px\s*!important/);
});

test("video review: date-event form remains scrollable with the native keyboard open", () => {
  assert.match(css, /#screen-date \.date-event-dialog-card\s*\{[^}]*max-height:\s*calc\(100dvh/);
  assert.match(css, /#screen-date \.date-event-dialog-card\s*\{[^}]*overflow-y:\s*auto\s*!important/);
  assert.match(css, /#screen-date \.date-event-dialog-actions\s*\{[^}]*position:\s*sticky\s*!important/);
});

test("video review: Android web bundle uses the exact reviewed stylesheet", () => {
  assert.equal(bundledCss, css);
});

test("video review: currency selector keeps flag, code, name and chevron in stable tracks", () => {
  assert.match(css, /#screen-currencies \.currency-select-wrap \{ display:flex !important/);
  assert.match(css, /#screen-currencies \.currency-select-wrap \.sumaire-select-trigger \{ flex:1 1 auto !important/);
});

test("video review: fuel-efficiency input labels do not render as stray background bands", () => {
  assert.match(css, /#screen-fuelefficiency \.calc-card \.input-row\s*\{[^}]*background:\s*transparent\s*!important/);
  assert.match(css, /#screen-fuelefficiency \.calc-card \.input-label\s*\{[^}]*background:\s*transparent\s*!important/);
});
